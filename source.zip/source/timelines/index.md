---
title: 更新日志
date: 2023-07-06 14:08:27
updated: 2023-07-12 03:08:39
categories: 
tags: 
---
# 更新日志
{% timeline 2023,purple %}
<!-- timeline 07-12 -->
**新增** 视频页
<!-- endtimeline -->
<!-- timeline 07-07 -->
配置Github Pages、Cloudflare Pages、Vercel同步部署
CF反向代理加速Github图床，~~虽然效果好像也不咋地~~
**新增** 关于页
<!-- endtimeline -->
<!-- timeline 07-06 -->
**新增** 更新日志、RSS订阅、bing sitemap
<!-- endtimeline -->
<!-- timeline 07-03 -->
启动pjax、aplayer底部音乐
<!-- endtimeline -->
<!-- timeline 07-01 -->
一图流界面、双栏首页
**新增** twikoo评论系统
从github pages到vercel
<!-- endtimeline -->
<!-- timeline 06-29 -->
**新增** bangumi追番页
<!-- endtimeline -->
<!-- timeline 06-25 -->
配置Hexo与Obisidian同步更新维护
<!-- endtimeline -->
<!-- timeline 06-11 -->
Hexo-6.3.0 + Butterfly-4.9.0 建站
<!-- endtimeline -->
{% endtimeline %}
